package br.com.manualdaprogramacao.helpdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpdeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
